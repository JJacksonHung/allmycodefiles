n = int(input("Input the total number of students(n>0): "))
s = []
v = []
i = 1

# 建立 s 列表
while i <= n:
    s.append(i)
    i += 1

# 建立 v 列表
i = 1
while len(v) < len(s):
    v.append(i)
    i = i % 3 + 1
j=0
while j<len(s):
    if v[j]==3:
        del s[j]  
        del v[j]
        j+=1
    j+=1

    
# 列印 s 和 v
print("s:", s)
print("v:", v)