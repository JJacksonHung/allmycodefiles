import random
from string import ascii_lowercase

# 將小寫字母分為6組
alphabet_groups = ['a-d', 'e-h', 'i-l', 'm-p', 'q-t', 'u-z']

# 生成隨機小寫字母
def generate_random_char():
    return random.choice(ascii_lowercase)

# 打印猜測直方圖
def print_histogram(guesses):
    print("Histogram of Guesses:")
    
    # 初始化每組的計數
    group_counts = {group: 0 for group in alphabet_groups}
    
    # 計算每個猜測落在哪一組
    for guess in guesses:
        for group in alphabet_groups:
            if guess in group.replace('-', ''):
                group_counts[group] += 1
                break
    
    # 打印每組的直方圖
    for group in alphabet_groups:
        count = group_counts[group]
        print(f"{group}: {'*' * (count // 4)}{'*' * (count % 4)}")

# 主遊戲循環
def main():
    # 生成隨機字母
    target_char = generate_random_char()

    # 初始化猜測列表
    guesses = []

    # 遊戲循環
    while True:
        # 提示用戶輸入猜測
        user_guess = input("Guess a lowercase alphabet character: ").lower()

        # 驗證用戶輸入
        if len(user_guess) != 1 or not user_guess.isalpha():
            if user_guess.isdigit():
                print("Please enter a lowercase alphabet.")
            else:
                print("Invalid input. Please enter a single lowercase alphabet character.")
            continue

        # 添加猜測到列表
        guesses.append(user_guess)

        # 檢查是否猜對
        if user_guess == target_char:
            print(f"Congratulations! You guessed the correct alphabet character: {target_char}")
            print(f"It took you {len(guesses)} tries.")
            print(f"Your guesses: {', '.join(guesses)}")
            print_histogram(guesses)
            break

        # 提供反饋
        elif user_guess < target_char:
            print("Your guess is too low. Try again.")
        else:
            print("Your guess is too high. Try again.")

# 運行主遊戲循環
if __name__ == "__main__":
    main()