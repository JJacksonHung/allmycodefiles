s = input("Enter a string：")

max_length = 0
start = 0
length = len(s)


for i in range(length):
   
    left, right = i, i
    while left >= 0 and right < length and s[left] == s[right]:
        if right - left + 1 > max_length:
            max_length = right - left + 1
            start = left
        left -= 1
        right += 1

    
    left, right = i, i + 1
    while left >= 0 and right < length and s[left] == s[right]:
        if right - left + 1 > max_length:
            max_length = right - left + 1
            start = left
        left -= 1
        right += 1


print("Longest palindrome substring：", s[start:start + max_length])
print("Length is: ",len(s[start:start + max_length]))
