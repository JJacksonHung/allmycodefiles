＃輸入範圍
n=input('Input the range number: ')
n=int(n)
＃從1開始驗證
i = 1
while i <= n:
    j = 1
    sum = 0
    while j < i:
    	＃驗證i是否被j除後是餘0
        if i % j == 0:
            sum += j
        j += 1
    ＃驗證總和是否為當前數字
    if sum == i:
    	＃如果是第一個完美數6前面要加perfect number
    	if i == 6:
    		print("Perfect numbers:\n6")
    	else:
    		print(i)
    i += 1