n=int(input("Input an integer number: "))
def fibo(n):
    if n == 0:
        return 0;
    elif n == 1:
        return 1;
    return fibo(n-1) + fibo(n-2)
fibo=fibo(n)
print("The",n,"-th Fibonacci sequence number is:",fibo)


