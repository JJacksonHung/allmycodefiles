s1="spam"
s2="ni!"
a='\"'+s2[0:2].upper()+'\"'
print(a)
b='\"'+s2+s1+s2+'\"'
print(b)
c='\"'+(s1.capitalize()+s2.capitalize()+' ')*3+'\"'
print(c)
d='\"'+s1[0:3]+"n"+'\"'
print(d)
e='\"'+s1[0:2]+"m"+'\"'
print(e)