import re

def evaluate_expression(expression):
    try:
        # Remove whitespace from the expression
        expression = expression.replace(" ", "")

        # Check for unsupported characters
        if not re.match(r'^[\d\+\-\*\/\(\)]+$', expression):
            return "Unsupported character error"

        # Check for unbalanced parentheses
        stack = []
        for char in expression:
            if char == '(':
                stack.append(char)
            elif char == ')':
                if not stack:
                    return "Unbalanced parentheses error"
                stack.pop()
        if stack:
            return "Unbalanced parentheses error"

        # Evaluate the expression
        try:
            result = str(eval(expression))
        except ZeroDivisionError:
            return "Division by zero error"

        return result

    except Exception as e:
        return str(e)

def main():
    while True:
        expression = input("Enter an arithmetic expression (or 'q' to quit): ")
        if expression.lower() == 'q':
            break
        result = evaluate_expression(expression)
        print(result)

if __name__ == "__main__":
    main()