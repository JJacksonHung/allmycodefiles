import csv

def top_3_movies_highest_ratings_in_2016():
    """
    Finds the top 3 movies with the highest ratings in 2016.
    """
    with open('IMDB-Movie-Data.csv', 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        movies_2016 = []
        for row in reader:
            if int(row['Year']) == 2016:
                movies_2016.append(row)

        sorted_movies = sorted(movies_2016, key=lambda movie: float(movie['Rating']), reverse=True)

        print("Top 3 movies with the highest ratings in 2016:")
        for i in range(3):
            print(f"Top {i+1}: {sorted_movies[i]['Title']}")

def director_with_most_movies():
    """
    Finds the director who has directed the most movies.
    """
    with open('IMDB-Movie-Data.csv', 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        directors = {}
        for row in reader:
            director = row['Director']
            if director in directors:
                directors[director] += 1
            else:
                directors[director] = 1

        most_movies_director = max(directors, key=directors.get)
        print(f"Director with most movies: {most_movies_director}")

def actor_with_highest_total_revenue():
    """
    Finds the actor with the highest total revenue.
    """
    with open('IMDB-Movie-Data.csv', 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        actors_revenue = {}
        for row in reader:
            actors = row['Actors'].split('|')
            for actor in actors:
                actor = actor.strip()
                try:
                    revenue = float(row['Revenue (Millions)'])
                except ValueError:
                    revenue = 0
                if actor in actors_revenue:
                    actors_revenue[actor] += revenue
                else:
                    actors_revenue[actor] = revenue

        max_revenue_actor = max(actors_revenue, key=actors_revenue.get)
        print(f"Actor with the highest total revenue: {max_revenue_actor} - ${actors_revenue[max_revenue_actor]:.2f} million")

def average_rating_of_emma_watsons_movies():
    """
    Calculates the average rating of Emma Watson's movies.
    """
    with open('IMDB-Movie-Data.csv', 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        emma_watsons_movies = []
        for row in reader:
            if 'Emma Watson' in row['Actors']:
                emma_watsons_movies.append(float(row['Rating']))

        average_rating = sum(emma_watsons_movies) / len(emma_watsons_movies)
        print(f"Average rating of Emma Watson's movies: {average_rating}")

def top_4_actors_with_most_movies():
    """
    Finds the top 4 actors who have played in the most movies.
    """
    with open('IMDB-Movie-Data.csv', 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        actors = {}
        for row in reader:
            actors_list = row['Actors'].split('|')
            for actor in actors_list:
                actor = actor.strip()
                if actor in actors:
                    actors[actor] += 1
                else:
                    actors[actor] = 1

        sorted_actors = sorted(actors.items(), key=lambda item: item[1], reverse=True)

        print("Top 4 actors with the most movies:")
        for i in range(4):
            print(f"Top {i+1}: {sorted_actors[i][0]} - {sorted_actors[i][1]} movies")

def top_7_frequent_collaboration_pairs():
    """
    Finds the top 7 frequent collaboration pairs of director and actor.
    """
    with open('IMDB-Movie-Data.csv', 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        director_actor_pairs = {}
        for row in reader:
            director = row['Director']
            actors = row['Actors'].split('|')
            for actor in actors:
                actor = actor.strip()
                pair = (director, actor)
                if pair in director_actor_pairs:
                    director_actor_pairs[pair] += 1
                else:
                    director_actor_pairs[pair] = 1

        sorted_pairs = sorted(director_actor_pairs.items(), key=lambda item: item[1], reverse=True)

        print("Top 7 frequent collaboration pairs:")
        for i in range(7):
            print(f"Top {i+1}: {sorted_pairs[i][0]} - {sorted_pairs[i][1]} collaborations")

def top_3_directors_with_most_actors():
    """
    Finds the top 3 directors who have collaborated with the most actors.
    """
    with open('IMDB-Movie-Data.csv', 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        director_actors = {}
        for row in reader:
            director = row['Director']
            actors = row['Actors'].split('|')
            if director in director_actors:
                director_actors[director].update(set(actor.strip() for actor in actors))
            else:
                director_actors[director] = set(actor.strip() for actor in actors)

        sorted_directors = sorted(director_actors.items(), key=lambda item: len(item[1]), reverse=True)

        print("Top 3 directors who collaborated with the most actors:")
        for i in range(3):
            print(f"Top {i+1}: {sorted_directors[i][0]} - {len(sorted_directors[i][1])} actors")

def top_6_actors_with_most_genres():
    """
    Finds the top 6 actors who have played in the most genres of movies.
    """
    with open('IMDB-Movie-Data.csv', 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        actor_genres = {}
        for row in reader:
            actors = row['Actors'].split('|')
            genres = row['Genre'].split('|')
            for actor in actors:
                actor = actor.strip()
                if actor in actor_genres:
                    actor_genres[actor].update(set(genre.strip() for genre in genres))
                else:
                    actor_genres[actor] = set(genre.strip() for genre in genres)

        sorted_actors = sorted(actor_genres.items(), key=lambda item: len(item[1]), reverse=True)

        print("Top 6 actors who have played in the most genres:")
        for i in range(6):
            print(f"Top {i+1}: {sorted_actors[i][0]} - {len(sorted_actors[i][1])} genres")

def top_3_actors_with_largest_year_gap():
    """
    Finds the top 3 actors with the largest gap of years between their movies.
    """
    with open('IMDB-Movie-Data.csv', 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        actor_years = {}
        for row in reader:
            actors = row['Actors'].split('|')
            year = int(row['Year'])
            for actor in actors:
                actor = actor.strip()
                if actor in actor_years:
                    actor_years[actor].append(year)
                else:
                    actor_years[actor] = [year]

        max_year_gaps = {}
        for actor, years in actor_years.items():
            years.sort()
            max_year_gap = years[-1] - years[0]
            max_year_gaps[actor] = max_year_gap

        sorted_actors = sorted(max_year_gaps.items(), key=lambda item: item[1], reverse=True)

        print("Top 3 actors with the largest gap of years between their movies:")
        for i in range(3):
            print(f"Top {i+1}: {sorted_actors[i][0]} - {sorted_actors[i][1]} years")

if __name__ == '__main__':
    top_3_movies_highest_ratings_in_2016()
    director_with_most_movies()
    actor_with_highest_total_revenue()
    average_rating_of_emma_watsons_movies()
    top_4_actors_with_most_movies()
    top_7_frequent_collaboration_pairs()
    top_3_directors_with_most_actors()
    top_6_actors_with_most_genres()
    top_3_actors_with_largest_year_gap()