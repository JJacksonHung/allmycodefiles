import random

def create_board(length=30):
  """Creates a board with safe and penalty squares.

  Args:
    length: The length of the board.

  Returns:
    A list representing the board, where each element is either 'S' for safe or 'P' for penalty.
  """
  board = []
  for _ in range(length):
    if random.random() < 0.3:
      board.append('P')
    else:
      board.append('S')
  return board

def roll_dice():
  """Simulates rolling a dice.

  Returns:
    An integer between 1 and 6.
  """
  return random.randint(1, 6)

def move_player(board, player_position, dice_roll):
  """Moves a player on the board.

  Args:
    board: The board represented as a list.
    player_position: The current position of the player.
    dice_roll: The result of the dice roll.

  Returns:
    The new position of the player.
  """
  new_position = player_position + dice_roll
  if new_position >= len(board):
    new_position = len(board) - 1
  return new_position

def print_board(board, player_a_position, player_b_position):
  """Prints the board with player positions marked.

  Args:
    board: The board represented as a list.
    player_a_position: The current position of Player A.
    player_b_position: The current position of Player B.
  """
  board_string = []
  for i in range(len(board)):
    if i == player_a_position and i == player_b_position:
      if board[i] == 'S':
        board_string.append('X')
      else:
        board_string.append('x')
    elif i == player_a_position:
      if board[i] == 'S':
        board_string.append('A')
      else:
        board_string.append('a')
    elif i == player_b_position:
      if board[i] == 'S':
        board_string.append('B')
      else:
        board_string.append('b')
    else:
      board_string.append('_')
  print(' '.join(board_string))

def play_game():
  """Plays the board game."""
  board = create_board()
  player_a_position = 0
  player_b_position = 0
  player_a_penalty = False
  player_b_penalty = False

  while player_a_position < len(board) - 1 or player_b_position < len(board) - 1:
    # Player A's turn
    if not player_a_penalty:
      dice_roll = roll_dice()
      print("Player A rolls: ",dice_roll)
      player_a_position = move_player(board, player_a_position, dice_roll)
      if board[player_a_position] == 'P':
        player_a_penalty = True
        print("Player A lands on a penalty square! Loses next turn.")
      else:
        player_a_penalty = False

    # Player B's turn
    if not player_b_penalty:
      dice_roll = roll_dice()
      print("Player B rolls:",dice_roll)
      player_b_position = move_player(board, player_b_position, dice_roll)
      if board[player_b_position] == 'P':
        player_b_penalty = True
        print("Player B lands on a penalty square! Loses next turn.")
      else:
        player_b_penalty = False

    # Print board after each turn
    print_board(board, player_a_position, player_b_position)

    # Check for winners
    if player_a_position == len(board) - 1 and player_b_position == len(board) - 1:
      print("Both players win!")
      break
    elif player_a_position == len(board) - 1:
      print("Player A wins!")
      break
    elif player_b_position == len(board) - 1:
      print("Player B wins!")
      break

  # Print the final board with penalty squares revealed
  print("Hidden penalty squares:")
  revealed_board = ['P' if x == 'P' else '_' for x in board]
  print(' '.join(revealed_board))

if __name__ == "__main__":
  play_game()