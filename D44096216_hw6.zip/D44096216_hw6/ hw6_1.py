def candyCrush(board):
    while True:
        # 1. Find all candies to crush
        to_crush = set()
        
        # Check horizontally
        for i in range(len(board)):
            for j in range(len(board[0]) - 2):
                if board[i][j] != 0 and abs(board[i][j]) == abs(board[i][j+1]) == abs(board[i][j+2]):
                    to_crush.update({(i, j), (i, j+1), (i, j+2)})
        
        # Check vertically
        for i in range(len(board) - 2):
            for j in range(len(board[0])):
                if board[i][j] != 0 and abs(board[i][j]) == abs(board[i+1][j]) == abs(board[i+2][j]):
                    to_crush.update({(i, j), (i+1, j), (i+2, j)})

        # If no candies to crush, the board is stable
        if not to_crush:
            break

        # Crush candies
        for i, j in to_crush:
            board[i][j] = 0

        # Drop candies
        for j in range(len(board[0])):
            empty_row = len(board) - 1
            for i in range(len(board) - 1, -1, -1):
                if board[i][j] != 0:
                    board[empty_row][j] = board[i][j]
                    if empty_row != i:
                        board[i][j] = 0
                    empty_row -= 1

    return board

# 測試範例
example_input1 = [
    [110, 5, 112, 113, 114],
    [210, 211, 5, 213, 214],
    [310, 311, 3, 313, 314],
    [410, 411, 412, 5, 414],
    [5, 1, 512, 3, 3],
    [610, 4, 1, 613, 614],
    [710, 1, 2, 713, 714],
    [810, 1, 2, 1, 1],
    [1, 1, 2, 2, 2],
    [4, 1, 4, 4, 1014]
]

example_output1 = candyCrush(example_input1)
for row in example_output1:
    print(row)
