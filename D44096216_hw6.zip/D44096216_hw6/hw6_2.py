import random

def print_board(board):
    for row in board:
        print(" ".join(str(cell) for cell in row))
    print()

def initialize_board(width, height, candy_types):
    return [[random.randint(1, candy_types) for _ in range(width)] for _ in range(height)]

def crush_candies(board):
    to_crush = set()
    for i in range(len(board)):
        for j in range(len(board[0]) - 2):
            if board[i][j] != 0 and abs(board[i][j]) == abs(board[i][j+1]) == abs(board[i][j+2]):
                to_crush.update({(i, j), (i, j+1), (i, j+2)})
    for i in range(len(board) - 2):
        for j in range(len(board[0])):
            if board[i][j] != 0 and abs(board[i][j]) == abs(board[i+1][j]) == abs(board[i+2][j]):
                to_crush.update({(i, j), (i+1, j), (i+2, j)})

    for i, j in to_crush:
        board[i][j] = 0

    return bool(to_crush)

def drop_candies(board, candy_types):
    for j in range(len(board[0])):
        empty_row = len(board) - 1
        for i in range(len(board) - 1, -1, -1):
            if board[i][j] != 0:
                board[empty_row][j] = board[i][j]
                if empty_row != i:
                    board[i][j] = 0
                empty_row -= 1

        for i in range(empty_row, -1, -1):
            board[i][j] = random.randint(1, candy_types)

def is_stable(board):
    for i in range(len(board)):
        for j in range(len(board[0]) - 2):
            if abs(board[i][j]) == abs(board[i][j+1]) == abs(board[i][j+2]):
                return False
    for i in range(len(board) - 2):
        for j in range(len(board[0])):
            if abs(board[i][j]) == abs(board[i+1][j]) == abs(board[i+2][j]):
                return False
    return True

def switch_and_crush(board, x1, y1, x2, y2):
    board[x1][y1], board[x2][y2] = board[x2][y2], board[x1][y1]
    while True:
        if not crush_candies(board):
            break
        drop_candies(board, candy_types)
    if not is_stable(board):
        board[x1][y1], board[x2][y2] = board[x2][y2], board[x1][y1]
        return False
    return True

def play_game():
    width = int(input("Enter the width of the board: "))
    height = int(input("Enter the height of the board: "))
    candy_types = int(input("Enter the number of candy types: "))

    board = initialize_board(width, height, candy_types)
    score = 0

    while True:
        print_board(board)
        print(f"Score: {score}")
        
        x1, y1 = map(int, input("Enter the coordinates of the first candy (row, column): ").split())
        x2, y2 = map(int, input("Enter the coordinates of the adjacent candy to switch (row, column): ").split())
        
        if abs(x1 - x2) + abs(y1 - y2) != 1:
            print("Invalid move. Please select two adjacent candies.")
            continue
        
        if switch_and_crush(board, x1, y1, x2, y2):
            score += 1
        else:
            print("Switch didn't cause any elimination. Try another move.")
        
        if score >= 20:  # Example condition to end the game
            print("Congratulations! You've reached the target score!")
            break

if __name__ == "__main__":
    play_game()
