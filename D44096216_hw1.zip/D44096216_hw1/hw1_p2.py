input_force=input("Input the force: ")
input_m1=input("Input the mass of m1: ")
input_dis=input("Input the distance: ")
g=6.67*10**(-11)
c=299792458
force=float(input_force)
m1=float(input_m1)
dis=float(input_dis)
m2=(force*dis**2)/(g*m1)
enegry=m2*c**2
print("The mass of m2=",m2,"The energy of m2=",enegry)